"""
CRIMINAL HOST — Vercel serverless entry point.
File: api/index.py

This exports the Flask `app` so Vercel can route all HTTP requests to it.
"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from criminal_host import app  # noqa: F401  — Vercel needs this name
