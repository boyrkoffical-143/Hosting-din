# CRIMINAL HOST (Vercel build)

Owner: @CRIMINAL_HUBBYx

## Deploy on Vercel
1. Upload this folder to GitHub (or Vercel CLI)
2. Import project on vercel.com
3. Framework: Other
4. Root directory: this folder
5. Deploy

Default login: **admin** / **admin123**

## Limits on Vercel
- UI (login, dashboard, upload page) can load
- Bot **processes do not stay running** (serverless kills them)
- For real bot hosting use **Railway** or **Render**

## Railway (recommended for bots)
```
pip install -r requirements.txt
gunicorn criminal_host:app -b 0.0.0.0:$PORT --workers 1 --threads 8
```
